﻿using System.ComponentModel.DataAnnotations;

public class TipoHabitacionRow
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Descripcion { get; set; } = "";
    public decimal Precio { get; set; }
}

public class TipoHabitacionFormVm
{
    public int? Id { get; set; }

    [Required] public string Nombre { get; set; } = "";
    [Required] public string Descripcion { get; set; } = "";
    [Range(1, 999999999)] public decimal Precio { get; set; }
}
