﻿using System.ComponentModel.DataAnnotations;

public class ReservaCreateVm
{
    [Required]
    public string Identificacion { get; set; } = "";

    [Required(ErrorMessage = "Debes seleccionar una habitación.")]
    public int IdHabitacion { get; set; }


    [Required]
    public DateTime FechaIngreso { get; set; } = DateTime.Now;

    [Required]
    public DateTime FechaSalida { get; set; } = DateTime.Now.AddDays(1);

    [Range(1, 20)]
    public int CantidadPersonas { get; set; } = 1;

    // Para llenar el combo de habitaciones disponibles
    public List<HabitacionOption> Habitaciones { get; set; } = new();
}

public class HabitacionOption
{
    public int IdHabitacion { get; set; }
    public string Texto { get; set; } = "";
}
