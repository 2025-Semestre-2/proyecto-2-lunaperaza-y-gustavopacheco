﻿using Microsoft.Data.SqlClient;

public class HotelesRepository
{
    private readonly DbConnFactory _factory;
    private readonly IHttpContextAccessor _http;

    public HotelesRepository(IConfiguration config, IHttpContextAccessor http)
    {
        _factory = new DbConnFactory(config);
        _http = http;
    }

    private SqlConnection OpenConn()
    {
        var user = _http.HttpContext!.Session.GetString("db_user");
        var pass = _http.HttpContext!.Session.GetString("db_pass");

        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            throw new Exception("No hay sesión iniciada.");

        var cs = _factory.Build(user, pass);
        var cn = new SqlConnection(cs);
        cn.Open();
        return cn;
    }

    public List<HotelDto> GetHoteles()
    {
        var list = new List<HotelDto>();

        using var cn = OpenConn();
        using var cmd = new SqlCommand(@"
            SELECT
                ID,
                Hotel,
                Provincia,
                Canton,
                Distrito,
                Pagina,
                [Teléfono]
            FROM dbo.vw_Hoteles
            ORDER BY Hotel;", cn);

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new HotelDto
            {
                ID = rd["ID"]?.ToString() ?? "",
                Hotel = rd["Hotel"]?.ToString() ?? "",
                Provincia = rd["Provincia"]?.ToString() ?? "",
                Canton = rd["Canton"]?.ToString() ?? "",
                Distrito = rd["Distrito"]?.ToString() ?? "",
                Pagina = rd["Pagina"]?.ToString() ?? "",
                Telefono = rd["Teléfono"]?.ToString() ?? ""
            });
        }

        return list;
    }
}

public class HotelDto
{
    public string ID { get; set; } = "";
    public string Hotel { get; set; } = "";
    public string Provincia { get; set; } = "";
    public string Canton { get; set; } = "";
    public string Distrito { get; set; } = "";
    public string Pagina { get; set; } = "";
    public string Telefono { get; set; } = "";
}
