﻿using Microsoft.Data.SqlClient;
using System.Data;

public class ReservasListRepository
{
    private readonly DbConnFactory _factory;
    private readonly IHttpContextAccessor _http;

    public ReservasListRepository(IConfiguration config, IHttpContextAccessor http)
    {
        _factory = new DbConnFactory(config);
        _http = http;
    }

    private SqlConnection OpenConn()
    {
        var user = _http.HttpContext!.Session.GetString("db_user");
        var pass = _http.HttpContext!.Session.GetString("db_pass");

        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            throw new Exception("No hay sesión iniciada.");

        var cs = _factory.Build(user, pass);
        var cn = new SqlConnection(cs);
        cn.Open();
        return cn;
    }

    public List<ReservaRowDto> GetReservas()
    {
        var list = new List<ReservaRowDto>();

        using var cn = OpenConn();
        using var cmd = new SqlCommand(@"
            SELECT
                IdReserva,
                Hotel,
                Habitacion,
                [#Habitacion] AS NumHabitacion,
                NombreCliente,
                IdentificacionCliente,
                [Fecha Ingreso] AS FechaIngreso,
                [Fecha Salida] AS FechaSalida,
                CantidadPersonas
            FROM dbo.vw_Reservas
            ORDER BY IdReserva DESC;", cn);

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new ReservaRowDto
            {
                IdReserva = Convert.ToInt32(rd["IdReserva"]),
                Hotel = rd["Hotel"]?.ToString() ?? "",
                Habitacion = rd["Habitacion"]?.ToString() ?? "",
                NumHabitacion = rd["NumHabitacion"]?.ToString() ?? "",
                NombreCliente = rd["NombreCliente"]?.ToString() ?? "",
                IdentificacionCliente = rd["IdentificacionCliente"]?.ToString() ?? "",
                FechaIngreso = Convert.ToDateTime(rd["FechaIngreso"]),
                FechaSalida = Convert.ToDateTime(rd["FechaSalida"]),
                CantidadPersonas = Convert.ToInt32(rd["CantidadPersonas"])
            });
        }

        return list;
    }

    public int CerrarReserva(int idReserva)
    {
        using var cn = OpenConn();
        using var cmd = new SqlCommand("dbo.sp_CerrarReserva", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@id_reserva", idReserva);

        // Tus SP “devuelven un entero”
        var result = cmd.ExecuteScalar();
        return result == null ? 0 : Convert.ToInt32(result);
    }
}

public class ReservaRowDto
{
    public int IdReserva { get; set; }
    public string Hotel { get; set; } = "";
    public string Habitacion { get; set; } = "";
    public string NumHabitacion { get; set; } = "";
    public string NombreCliente { get; set; } = "";
    public string IdentificacionCliente { get; set; } = "";
    public DateTime FechaIngreso { get; set; }
    public DateTime FechaSalida { get; set; }
    public int CantidadPersonas { get; set; }
}
