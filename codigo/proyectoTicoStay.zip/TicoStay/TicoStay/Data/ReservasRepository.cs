﻿using Microsoft.Data.SqlClient;
using System.Data;

public class ReservasRepository
{
    private readonly DbConnFactory _factory;
    private readonly IHttpContextAccessor _http;

    public ReservasRepository(IConfiguration config, IHttpContextAccessor http)
    {
        _factory = new DbConnFactory(config);
        _http = http;
    }

    private SqlConnection OpenConn()
    {
        var user = _http.HttpContext!.Session.GetString("db_user");
        var pass = _http.HttpContext!.Session.GetString("db_pass");

        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            throw new Exception("No hay sesión iniciada.");

        var cs = _factory.Build(user, pass);
        var cn = new SqlConnection(cs);
        cn.Open();
        return cn;
    }

    // Llenar el combo desde la vista dbo.vw_HabitacionDisponible
    public List<HabitacionOption> GetHabitacionesDisponibles()
    {
        var list = new List<HabitacionOption>();

        using var cn = OpenConn();
        using var cmd = new SqlCommand(@"
        SELECT 
            IDHabitacion,
            Hotel,
            Habitacion,
            [#Habitacion] AS NumHabitacion,
            Estado
        FROM dbo.vw_HabitacionDisponible
        WHERE Estado = 'Disponible' OR Estado = 'DISPONIBLE' OR Estado = 'LIBRE'
        ORDER BY Hotel, Habitacion, [#Habitacion];", cn);

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var id = Convert.ToInt32(rd["IDHabitacion"]);
            var hotel = rd["Hotel"]?.ToString() ?? "";
            var tipo = rd["Habitacion"]?.ToString() ?? "";
            var num = rd["NumHabitacion"]?.ToString() ?? "";
            var estado = rd["Estado"]?.ToString() ?? "";

            list.Add(new HabitacionOption
            {
                IdHabitacion = id,
                Texto = $"{hotel} | {tipo} #{num} | {estado}"
            });
        }

        return list;
    }
    

    // Ejecuta el SP (DML SOLO por SP ✅)
    public void CrearReserva(string identificacion, int idHabitacion, DateTime fechaIngreso, DateTime fechaSalida, int cantidadPersonas)
    {
        using var cn = OpenConn();
        using var cmd = new SqlCommand("dbo.sp_CrearReserva", cn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@identificacion", identificacion);
        cmd.Parameters.AddWithValue("@id_habitacion", idHabitacion);
        cmd.Parameters.AddWithValue("@fecha_ingreso", fechaIngreso);
        cmd.Parameters.AddWithValue("@fecha_salida", fechaSalida);
        cmd.Parameters.AddWithValue("@cantidad_personas", cantidadPersonas);

        cmd.ExecuteNonQuery();
    }
}
