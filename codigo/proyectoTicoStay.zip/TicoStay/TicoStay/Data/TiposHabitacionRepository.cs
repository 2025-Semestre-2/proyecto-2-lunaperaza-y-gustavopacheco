﻿using Microsoft.Data.SqlClient;
using System.Data;

public class TiposHabitacionRepository
{
    private readonly DbConnFactory _factory;
    private readonly IHttpContextAccessor _http;

    public TiposHabitacionRepository(IConfiguration config, IHttpContextAccessor http)
    {
        _factory = new DbConnFactory(config);
        _http = http;
    }

    private SqlConnection OpenConn()
    {
        var user = _http.HttpContext!.Session.GetString("db_user");
        var pass = _http.HttpContext!.Session.GetString("db_pass");
        var cs = _factory.Build(user!, pass!);
        var cn = new SqlConnection(cs);
        cn.Open();
        return cn;
    }

    public List<TipoHabitacionRow> Listar()
    {
        var list = new List<TipoHabitacionRow>();
        using var cn = OpenConn();

        // Ajusta el nombre de la vista si en tu BD es distinto:
        using var cmd = new SqlCommand("SELECT * FROM dbo.vw_TiposHabitaciones;", cn);
        using var rd = cmd.ExecuteReader();

        while (rd.Read())
        {
            // IMPORTANTÍSIMO: si tus columnas tienen nombres distintos, cambia aquí.
            list.Add(new TipoHabitacionRow
            {
                Id = Convert.ToInt32(rd[0]),
                Nombre = rd["nombre"]?.ToString() ?? rd["Nombre"]?.ToString() ?? "",
                Descripcion = rd["descripcion"]?.ToString() ?? rd["Descripcion"]?.ToString() ?? "",
                Precio = Convert.ToDecimal(rd["precio"] ?? rd["Precio"])
            });
        }

        return list;
    }

    public void Insertar(string nombre, string descripcion, decimal precio)
    {
        using var cn = OpenConn();
        using var cmd = new SqlCommand("dbo.sp_InsertarTipoHabitacion", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@nombre", nombre);
        cmd.Parameters.AddWithValue("@descripcion", descripcion);
        cmd.Parameters.AddWithValue("@precio", precio);
        cmd.ExecuteNonQuery();
    }

    public void Actualizar(int id, string nombre, string descripcion, decimal precio)
    {
        using var cn = OpenConn();
        using var cmd = new SqlCommand("dbo.sp_ActualizarTipoHabitacion", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@id_tipo", id);
        cmd.Parameters.AddWithValue("@nombre", nombre);
        cmd.Parameters.AddWithValue("@descripcion", descripcion);
        cmd.Parameters.AddWithValue("@precio", precio);
        cmd.ExecuteNonQuery();
    }
}
