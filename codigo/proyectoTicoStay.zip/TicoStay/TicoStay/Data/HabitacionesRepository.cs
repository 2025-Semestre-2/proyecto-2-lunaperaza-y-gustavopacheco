﻿using System.Data;
using Microsoft.Data.SqlClient;



public class HabitacionesRepository
{
    private readonly DbConnFactory _factory;
    private readonly IHttpContextAccessor _http;

    public HabitacionesRepository(IConfiguration config, IHttpContextAccessor http)
    {
        _factory = new DbConnFactory(config);
        _http = http;
    }

    private SqlConnection OpenConn()
    {
        var user = _http.HttpContext!.Session.GetString("db_user");
        var pass = _http.HttpContext!.Session.GetString("db_pass");
        var cs = _factory.Build(user!, pass!);
        var cn = new SqlConnection(cs);
        cn.Open();
        return cn;
    }

    public List<HabitacionInfoRow> Listar()
    {
        var list = new List<HabitacionInfoRow>();
        using var cn = OpenConn();

        using var cmd = new SqlCommand(@"
            SELECT
              Hotel,
              IDHabitacion,
              Habitacion,
              [#Habitacion] AS NumHabitacion,
              Estado
            FROM dbo.vw_HabitacionesInfo;", cn);

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new HabitacionInfoRow
            {
                Hotel = rd["Hotel"]?.ToString() ?? "",
                IdHabitacion = Convert.ToInt32(rd["IDHabitacion"]),
                Habitacion = rd["Habitacion"]?.ToString() ?? "",
                NumHabitacion = rd["NumHabitacion"]?.ToString() ?? "",
                Estado = rd["Estado"]?.ToString() ?? ""
            });
        }
        return list;
    }

    public void CambiarEstado(int idHabitacion, string estado)
    {
        using var cn = OpenConn();
        using var cmd = new SqlCommand("dbo.sp_CambiarEstadoHabitacion", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@id_habitacion", idHabitacion);
        cmd.Parameters.AddWithValue("@estado", estado);
        cmd.ExecuteNonQuery();
    }
}

public class HabitacionInfoRow
{
    public string Hotel { get; set; } = "";
    public int IdHabitacion { get; set; }
    public string Habitacion { get; set; } = "";
    public string NumHabitacion { get; set; } = "";
    public string Estado { get; set; } = "";
}
