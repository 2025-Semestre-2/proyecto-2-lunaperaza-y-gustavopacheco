﻿using Microsoft.Data.SqlClient;

public class DbConnFactory
{
    private readonly IConfiguration _config;
    public DbConnFactory(IConfiguration config) => _config = config;

    public string Build(string user, string pass)
    {
        var server = _config["Db:Server"];
        var db = _config["Db:Database"];
        var trust = _config["Db:TrustServerCertificate"] == "true";

        var csb = new SqlConnectionStringBuilder
        {
            DataSource = server,
            InitialCatalog = db,
            UserID = user,
            Password = pass,

            Encrypt = false,                 // <-- IMPORTANTE
            TrustServerCertificate = true    // <-- IMPORTANTE
        };


        return csb.ConnectionString;
    }



}
