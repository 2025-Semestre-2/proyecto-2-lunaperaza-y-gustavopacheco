﻿using Microsoft.Data.SqlClient;

public class HabitacionDisponibleRepository
{
    private readonly DbConnFactory _factory;
    private readonly IHttpContextAccessor _http;

    public HabitacionDisponibleRepository(IConfiguration config, IHttpContextAccessor http)
    {
        _factory = new DbConnFactory(config);
        _http = http;
    }

    private SqlConnection OpenConn()
    {
        var user = _http.HttpContext!.Session.GetString("db_user");
        var pass = _http.HttpContext!.Session.GetString("db_pass");

        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            throw new Exception("No hay sesión iniciada.");

        var cs = _factory.Build(user, pass);
        var cn = new SqlConnection(cs);
        cn.Open();
        return cn;
    }

    public List<HabitacionDisponibleDto> GetDisponibles()
    {
        var list = new List<HabitacionDisponibleDto>();

        using var cn = OpenConn();
        using var cmd = new SqlCommand(@"
            SELECT
                Hotel,
                IDHabitacion,
                Habitacion,
                [#Habitacion],
                Estado
            FROM dbo.vw_HabitacionDisponible
            ORDER BY Hotel, Habitacion, [#Habitacion];", cn);

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new HabitacionDisponibleDto
            {
                Hotel = rd["Hotel"]?.ToString() ?? "",
                IDHabitacion = rd["IDHabitacion"]?.ToString() ?? "",
                Habitacion = rd["Habitacion"]?.ToString() ?? "",
                NumHabitacion = rd["#Habitacion"]?.ToString() ?? "",
                Estado = rd["Estado"]?.ToString() ?? ""
            });
        }

        return list;
    }
}

public class HabitacionDisponibleDto
{
    public string Hotel { get; set; } = "";
    public string IDHabitacion { get; set; } = "";
    public string Habitacion { get; set; } = "";
    public string NumHabitacion { get; set; } = "";
    public string Estado { get; set; } = "";
}
