﻿using Microsoft.Data.SqlClient;
using System.Data;

public class FacturasRepository
{
    private readonly DbConnFactory _factory;
    private readonly IHttpContextAccessor _http;

    public FacturasRepository(IConfiguration config, IHttpContextAccessor http)
    {
        _factory = new DbConnFactory(config);
        _http = http;
    }

    private SqlConnection OpenConn()
    {
        var user = _http.HttpContext!.Session.GetString("db_user");
        var pass = _http.HttpContext!.Session.GetString("db_pass");

        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            throw new Exception("No hay sesión iniciada.");

        var cs = _factory.Build(user, pass);
        var cn = new SqlConnection(cs);
        cn.Open();
        return cn;
    }

    public List<FacturaRowDto> GetFacturas()
    {
        var list = new List<FacturaRowDto>();

        using var cn = OpenConn();
        using var cmd = new SqlCommand(@"
            SELECT
                Factura,
                Reserva,
                Hotel,
                NombreCliente,
                IdentificacionCliente,
                Cargos,
                [Cantidad de Noches] AS CantidadNoches,
                [Fecha Registro] AS FechaRegistro,
                Total,
                [Método de Pago] AS MetodoPago
            FROM dbo.vw_Factura
            ORDER BY Factura DESC;", cn);

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new FacturaRowDto
            {
                IdFactura = Convert.ToInt32(rd["Factura"]),
                Reserva = rd["Reserva"]?.ToString() ?? "",
                Hotel = rd["Hotel"]?.ToString() ?? "",
                NombreCliente = rd["NombreCliente"]?.ToString() ?? "",
                IdentificacionCliente = rd["IdentificacionCliente"]?.ToString() ?? "",
                Cargos = rd["Cargos"]?.ToString() ?? "",
                CantidadNoches = rd["CantidadNoches"]?.ToString() ?? "",
                FechaRegistro = rd["FechaRegistro"]?.ToString() ?? "",
                Total = rd["Total"]?.ToString() ?? "",
                MetodoPago = rd["MetodoPago"]?.ToString() ?? ""
            });
        }

        return list;
    }

    public int PagarFactura(int idFactura, string metodoPago)
    {
        using var cn = OpenConn();
        using var cmd = new SqlCommand("dbo.sp_PagarFactura", cn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@id_factura", idFactura);
        cmd.Parameters.AddWithValue("@metodo_pago", metodoPago);

        var result = cmd.ExecuteScalar();
        return result == null ? 0 : Convert.ToInt32(result);
    }
}

public class FacturaRowDto
{
    public int IdFactura { get; set; }
    public string Reserva { get; set; } = "";
    public string Hotel { get; set; } = "";
    public string NombreCliente { get; set; } = "";
    public string IdentificacionCliente { get; set; } = "";
    public string Cargos { get; set; } = "";
    public string CantidadNoches { get; set; } = "";
    public string FechaRegistro { get; set; } = "";
    public string Total { get; set; } = "";
    public string MetodoPago { get; set; } = "";
}
