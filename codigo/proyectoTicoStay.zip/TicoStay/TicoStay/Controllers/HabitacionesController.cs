﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoVerano.Controllers
{
    public class HabitacionesController : BaseController
    {
        private readonly HabitacionesRepository _repo;

        public HabitacionesController(IConfiguration config, IHttpContextAccessor http)
        {
            _repo = new HabitacionesRepository(config, http);
        }

        public IActionResult Index()
        {
            if (!IsLogged()) return RedirectToLogin();
            if (HttpContext.Session.GetString("is_admin") != "1") return Forbid();

            return View(_repo.Listar());
        }

        [HttpPost]
        public IActionResult CambiarEstado(int id_habitacion, string estado)
        {
            if (!IsLogged()) return RedirectToLogin();
            if (HttpContext.Session.GetString("is_admin") != "1") return Forbid();

            _repo.CambiarEstado(id_habitacion, estado);
            TempData["ok"] = "Estado actualizado.";
            return RedirectToAction("Index");
        }
    }
}
