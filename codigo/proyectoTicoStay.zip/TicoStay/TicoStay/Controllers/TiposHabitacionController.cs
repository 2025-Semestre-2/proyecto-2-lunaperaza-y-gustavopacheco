﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoVerano.Controllers
{
    public class TiposHabitacionController : BaseController
    {
        private readonly TiposHabitacionRepository _repo;

        public TiposHabitacionController(IConfiguration config, IHttpContextAccessor http)
        {
            _repo = new TiposHabitacionRepository(config, http);
        }

        public IActionResult Index()
        {
            if (!IsLogged()) return RedirectToLogin();
            if (HttpContext.Session.GetString("is_admin") != "1") return Forbid();

            ViewBag.Form = new TipoHabitacionFormVm();
            return View(_repo.Listar());
        }

        [HttpPost]
        public IActionResult Crear(TipoHabitacionFormVm vm)
        {
            if (!IsLogged()) return RedirectToLogin();
            if (HttpContext.Session.GetString("is_admin") != "1") return Forbid();

            if (!ModelState.IsValid)
            {
                ViewBag.Form = vm;
                return View("Index", _repo.Listar());
            }

            _repo.Insertar(vm.Nombre, vm.Descripcion, vm.Precio);
            TempData["ok"] = "Tipo de habitación creado.";
            return RedirectToAction("Index");
        }
    }
}
