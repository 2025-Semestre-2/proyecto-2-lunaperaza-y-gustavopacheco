﻿using Microsoft.AspNetCore.Mvc;
using ProyectoVerano.Controllers;

namespace ProyectoVeranoWeb.Controllers
{
    public class FacturasController : BaseController
    {
        private readonly FacturasRepository _repo;

        public FacturasController(IConfiguration config, IHttpContextAccessor http)
        {
            _repo = new FacturasRepository(config, http);
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (!IsLogged()) return RedirectToLogin();

            var data = _repo.GetFacturas();
            return View(data);
        }

        [HttpPost]
        public IActionResult Pagar(int id_factura, string metodo_pago)
        {
            if (!IsLogged()) return RedirectToLogin();

            if (HttpContext.Session.GetString("is_admin") != "1")
                return Forbid();

            if (string.IsNullOrWhiteSpace(metodo_pago))
            {
                TempData["err"] = "Debes indicar el método de pago.";
                return RedirectToAction("Index");
            }

            try
            {
                _repo.PagarFactura(id_factura, metodo_pago);
                TempData["ok"] = $"Factura #{id_factura} pagada.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["err"] = ex.Message;
                return RedirectToAction("Index");
            }
        }
    }
}
