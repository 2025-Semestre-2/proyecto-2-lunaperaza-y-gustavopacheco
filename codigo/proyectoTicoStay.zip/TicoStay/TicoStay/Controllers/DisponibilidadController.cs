﻿using Microsoft.AspNetCore.Mvc;
using ProyectoVerano.Controllers;

namespace ProyectoVerano.Controllers
{
    public class DisponibilidadController : BaseController
    {
        private readonly HabitacionDisponibleRepository _repo;

        public DisponibilidadController(IConfiguration config, IHttpContextAccessor http)
        {
            _repo = new HabitacionDisponibleRepository(config, http);
        }

        public IActionResult Index()
        {
            if (!IsLogged()) return RedirectToLogin();

            var data = _repo.GetDisponibles();
            return View(data);
        }
    }
}
