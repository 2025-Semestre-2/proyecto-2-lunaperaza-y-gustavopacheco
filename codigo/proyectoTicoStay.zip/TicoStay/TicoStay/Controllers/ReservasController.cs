﻿using Microsoft.AspNetCore.Mvc;
using ProyectoVerano.Controllers;

namespace ProyectoVerano.Controllers
{

    

    public class ReservasController : BaseController
    {
        private readonly ReservasRepository _repo;
        private readonly ReservasListRepository _listRepo;
        public ReservasController(IConfiguration config, IHttpContextAccessor http)
        {
            _repo = new ReservasRepository(config, http);
            _listRepo = new ReservasListRepository(config, http);

        }

        [HttpGet]
        public IActionResult Nueva()
        {
            if (!IsLogged()) return RedirectToLogin();

            var vm = new ReservaCreateVm
            {
                Habitaciones = _repo.GetHabitacionesDisponibles()
            };

            return View(vm);
        }
        [HttpGet]
        public IActionResult Index()
        {
            if (!IsLogged()) return RedirectToLogin();

            var data = _listRepo.GetReservas();
            return View(data);
        }

        [HttpPost]
        public IActionResult Cerrar(int id)
        {
            if (!IsLogged()) return RedirectToLogin();

            // Solo admin
            if (HttpContext.Session.GetString("is_admin") != "1")
                return Forbid();

            try
            {
                _listRepo.CerrarReserva(id);
                TempData["ok"] = $"Reserva #{id} cerrada. (Si tu trigger está bien, ya debe existir factura pendiente)";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["err"] = ex.Message;
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Nueva(ReservaCreateVm vm)
        {
            if (!IsLogged()) return RedirectToLogin();

            // Recargar combo siempre (por si hay error y se vuelve a mostrar el form)
            vm.Habitaciones = _repo.GetHabitacionesDisponibles();

            // Validaciones básicas
            if (string.IsNullOrWhiteSpace(vm.Identificacion))
                ModelState.AddModelError("", "La identificación es requerida.");

            if (vm.FechaSalida <= vm.FechaIngreso)
                ModelState.AddModelError("", "La fecha de salida debe ser mayor que la de ingreso.");

            if (!ModelState.IsValid)
                return View(vm);


            try
            {
                _repo.CrearReserva(vm.Identificacion, vm.IdHabitacion, vm.FechaIngreso, vm.FechaSalida, vm.CantidadPersonas);

                TempData["ok"] = "Reserva creada correctamente.";
                return RedirectToAction("Nueva");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(vm);
            }
        }
    }
}
