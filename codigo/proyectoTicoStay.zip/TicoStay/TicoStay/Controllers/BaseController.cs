﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoVerano.Controllers
{
    public class BaseController : Controller
    {
        protected bool IsLogged()
            => HttpContext.Session.GetString("db_user") != null;

        protected IActionResult RedirectToLogin()
            => RedirectToAction("Login", "Account");
    }
}
