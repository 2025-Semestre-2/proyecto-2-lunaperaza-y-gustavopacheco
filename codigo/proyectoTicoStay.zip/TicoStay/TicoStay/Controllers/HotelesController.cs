﻿using Microsoft.AspNetCore.Mvc;
using ProyectoVerano.Controllers;

namespace ProyectoVerano.Controllers
{
    public class HotelesController : BaseController
    {
        private readonly HotelesRepository _repo;

        public HotelesController(IConfiguration config, IHttpContextAccessor http)
        {
            _repo = new HotelesRepository(config, http);
        }

        public IActionResult Index(string? q)
        {
            if (!IsLogged()) return RedirectToLogin();

            var data = _repo.GetHoteles(); // tu repo ya lee vw_Hoteles
            if (!string.IsNullOrWhiteSpace(q))
            {
                q = q.Trim().ToLower();
                data = data.Where(h =>
                    (h.Hotel ?? "").ToLower().Contains(q) ||
                    (h.Provincia ?? "").ToLower().Contains(q) ||
                    (h.Canton ?? "").ToLower().Contains(q) ||
                    (h.Distrito ?? "").ToLower().Contains(q)
                ).ToList();
            }

            ViewBag.Q = q;
            return View(data);
        }
    }

    }
