﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoVerano.Controllers
{
    public class AccountController : Controller
    {
        private readonly DbConnFactory _factory;

        public AccountController(IConfiguration config)
        {
            _factory = new DbConnFactory(config);
        }

        [HttpGet]
        public IActionResult Login() => View(new LoginVm());

        [HttpPost]
        public IActionResult Login(LoginVm vm)
        {
            if (string.IsNullOrWhiteSpace(vm.Username) || string.IsNullOrWhiteSpace(vm.Password))
            {
                ViewBag.Error = "Falta usuario o contraseña.";
                return View(vm); // ✅ importante: devolver el modelo
            }

            try
            {
                var cs = _factory.Build(vm.Username, vm.Password);

                using var cn = new Microsoft.Data.SqlClient.SqlConnection(cs);
                cn.Open();

                using var cmd = new Microsoft.Data.SqlClient.SqlCommand("SELECT IS_ROLEMEMBER('AdminRole');", cn);
                var isAdmin = Convert.ToInt32(cmd.ExecuteScalar()) == 1;

                HttpContext.Session.SetString("db_user", vm.Username);
                HttpContext.Session.SetString("db_pass", vm.Password);
                HttpContext.Session.SetString("is_admin", isAdmin ? "1" : "0");

                return RedirectToAction("Index", "Hoteles");
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(vm); // ✅ importante: devolver el modelo
            }
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Account"); // ✅ explícito
        }

        [HttpGet]
        public IActionResult Perfil()
        {
            if (HttpContext.Session.GetString("db_user") == null)
                return RedirectToAction("Login", "Account");

            return View();
        }

    }
}
