﻿namespace TicoStay.Views
{
    public class TiposHabitacion
    {
    }
}
